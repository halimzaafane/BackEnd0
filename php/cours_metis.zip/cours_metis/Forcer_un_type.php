<?php
$myString = "Vive les formateurs";
$myInteger = (integer)$myString;
var_dump($myInteger)
?>

<?php
$petiteVar
?>